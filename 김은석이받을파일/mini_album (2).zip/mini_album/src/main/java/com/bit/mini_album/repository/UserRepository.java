package com.bit.mini_album.repository;

import com.bit.mini_album.entity.UserEntity2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.PathVariable;

import javax.transaction.Transactional;
import java.util.Optional;

@Transactional
public interface UserRepository extends JpaRepository<UserEntity2, Long> {
    Optional<UserEntity2> findByUserId(String userId);

    @Modifying
    @Query(value="update user_entity2" +
            "       set bamtori = :bamtori" +
            "       where u_id = :uId", nativeQuery = true)
    void saveBamtori(@Param("uId") long uId, @Param("bamtori") int bamtori);
}

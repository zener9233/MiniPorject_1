package com.bit.mini_album.repository;

import com.bit.mini_album.entity.PurchasedProductEntity;
import com.bit.mini_album.entity.UserEntity2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PurchasedProductRepository extends JpaRepository<PurchasedProductEntity, Long> {
    List<PurchasedProductEntity> findByUserEntity2(UserEntity2 user);
}

package com.bit.mini_album.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long pId;
    private long pcId;
    private String productCategory;
    private String productName;
    private int productPrice;
    private String productFilePath;
    private String productFileName;

    //카테고리 아이디


   // 그럼 아이템들 구분은? 카테고리를 만들어서 구분해준다.

}

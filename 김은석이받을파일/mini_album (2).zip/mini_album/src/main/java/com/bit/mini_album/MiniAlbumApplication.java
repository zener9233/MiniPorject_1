package com.bit.mini_album;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniAlbumApplication {

    public static void main(String[] args) {
        SpringApplication.run(MiniAlbumApplication.class, args);
    }

}

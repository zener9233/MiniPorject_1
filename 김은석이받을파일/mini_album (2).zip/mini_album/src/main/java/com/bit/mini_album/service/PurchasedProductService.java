package com.bit.mini_album.service;

import com.bit.mini_album.entity.ProductEntity;
import com.bit.mini_album.entity.PurchasedProductEntity;
import com.bit.mini_album.entity.UserEntity2;
import com.bit.mini_album.repository.ProductRepository;
import com.bit.mini_album.repository.PurchasedProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PurchasedProductService {

    private PurchasedProductRepository purchasedProductRepository;

    private ProductRepository productRepository;
    @Autowired
    public PurchasedProductService(PurchasedProductRepository purchasedProductRepository,
                                   ProductRepository productRepository) {
        this.purchasedProductRepository = purchasedProductRepository;
        this.productRepository = productRepository;
    }

    public void purchase(PurchasedProductEntity purchasedProductEntity) {

        purchasedProductRepository.save(purchasedProductEntity);

    }

    public ProductEntity getProductInfo(long pId) {
        if(productRepository.findById(pId).isEmpty())
            return null;

        return productRepository.findById(pId).get();
    }

    public List<PurchasedProductEntity> getOwingProduct(UserEntity2 user) {
        return purchasedProductRepository.findByUserEntity2(user);
    }
}

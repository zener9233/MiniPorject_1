package com.bit.mini_album.controller;

import com.bit.mini_album.entity.ProductEntity;
import com.bit.mini_album.entity.PurchasedProductEntity;
import com.bit.mini_album.entity.ResponseDTO;
import com.bit.mini_album.entity.UserEntity2;
import com.bit.mini_album.service.PurchasedProductService;
import com.bit.mini_album.service.UserService;
import org.springframework.boot.Banner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class PurchasedProductController {
    private final PurchasedProductService purchasedProductService;
    private final UserService userService;


    public PurchasedProductController(PurchasedProductService purchasedProductService, UserService userService) {
        this.purchasedProductService = purchasedProductService;
        this.userService = userService;
    }

    @GetMapping("/purchase/{uId}")
    public String purchaseView(@PathVariable("uId") String uId, HttpSession session) {

        UserEntity2 loginUser = (UserEntity2) session.getAttribute("loginUser");

        if(loginUser == null) {
            return "redirect:/login";
        }
        return "miniroom";
    }

    @PostMapping("/purchase")
    public ResponseEntity<?> purchase(HttpSession session,
                                   ProductEntity productEntity,
                                      UserEntity2 userEntity2) {
        ResponseDTO<Map<String, String>> responseDTO = new ResponseDTO<>();

        try {
            Map<String, String> returnMap = new HashMap<>();

            PurchasedProductEntity purchasedProductEntity = new PurchasedProductEntity();

            UserEntity2 loginUser = (UserEntity2) session.getAttribute("loginUser");
            productEntity = purchasedProductService.getProductInfo(productEntity.getPId());

            purchasedProductEntity.setUserEntity2(loginUser);
            purchasedProductEntity.setProductEntity(productEntity);

            if(loginUser.getBamtori() < productEntity.getProductPrice()) {
                returnMap.put("msg", "charge");
            } else {
                loginUser.setBamtori(loginUser.getBamtori() - productEntity.getProductPrice());
                userService.saveBamtori(loginUser);
                System.out.println("밤개수" + loginUser.getBamtori());
                purchasedProductEntity.setProductEntity(productEntity);
                purchasedProductService.purchase(purchasedProductEntity);
                returnMap.put("msg", "complete");
            }
            responseDTO.setItem(returnMap);
            responseDTO.setStatusCode(HttpStatus.OK.value());

            return ResponseEntity.ok().body(responseDTO);

        } catch (Exception e) {
            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
            responseDTO.setErrorMessage(e.getMessage());
            return ResponseEntity.badRequest().body(responseDTO);
        }
    }

    @ResponseBody //ajax로 값을 받을떈 responsebody를 쓴다. (restcontroller를 썻다면 필요없었다)
    @RequestMapping(value = "/preview", method = RequestMethod.GET)
    public List<ProductEntity> preview(HttpSession session) { //ajax로 주고받을 데이터의 형식이 productentitiy타입의 list라서 리턴타입도 맞춰준다.
        System.out.println("=========");

        UserEntity2 loginUser = (UserEntity2) session.getAttribute("loginUser"); //세션에 저장된 로그인 유저의 데이터를 불러온다

        List<PurchasedProductEntity> purchasedProductEntityList
                = purchasedProductService.getOwingProduct(loginUser); //아이디별로 구입한 상품을 리스트화 시켜서 가져온다.

        List<ProductEntity> productEntityList = new ArrayList<>();
        for (int i = 0; i < purchasedProductEntityList.size(); i++) {
            productEntityList.add(purchasedProductEntityList.get(i).getProductEntity()); //판매상품에 대한 정보를 가져오기위해 로그인한 유저의 구입한
                                                                                         //상품으로 상품정보를 담는다.(너가 데이터테이블을 그렇게 짰음)
        }

        return productEntityList;
    }
}

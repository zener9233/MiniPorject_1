package com.bit.mini_album.controller;

import com.bit.mini_album.entity.PurchasedProductEntity;
import com.bit.mini_album.entity.UserEntity2;
import com.bit.mini_album.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpSession;

@Controller
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/signup")
    public String signupForm() {
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(UserEntity2 userEntity2) {

        userService.signup(userEntity2);

        return "login";
    }

    @GetMapping("/")
    public String loginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(UserEntity2 userEntity2, HttpSession session) {
        UserEntity2 loginUser = userService.login(userEntity2);
        session.setAttribute("loginUser", loginUser);
        System.out.println("-------");
        System.out.println(session.getAttribute("loginUser"));
        return "redirect:/miniroom";
    }

}

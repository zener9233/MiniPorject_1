package com.bit.mini_album.repository;

import com.bit.mini_album.entity.PictureBoardEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PictureBoardRepository extends JpaRepository<PictureBoardEntity, Long> {

    Page<PictureBoardEntity> findByTitleContaining(String searchKeyword, Pageable pageable);
}

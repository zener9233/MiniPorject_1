package com.bit.mini_album;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniAlbumApplicationTests {

    @Test
    void contextLoads() {
    }

}

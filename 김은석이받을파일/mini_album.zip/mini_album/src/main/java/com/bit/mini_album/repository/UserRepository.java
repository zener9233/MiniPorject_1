package com.bit.mini_album.repository;

import com.bit.mini_album.entity.UserEntity2;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<UserEntity2, Long> {
    Optional<UserEntity2> findByUserId(String userId);
}

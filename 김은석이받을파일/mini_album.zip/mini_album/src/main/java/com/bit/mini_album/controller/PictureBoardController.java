package com.bit.mini_album.controller;

import com.bit.mini_album.entity.PictureBoardEntity;
import com.bit.mini_album.service.PictureBoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequiredArgsConstructor
public class PictureBoardController {
    private final PictureBoardService pictureBoardService;

    @GetMapping("/pBoard/write")
    public String pBoardWriteForm() {
        return "pBoardWrite";
    }


    @PostMapping("/pBoard/write")
    public String pBoardWrite(PictureBoardEntity pictureBoardEntity,
                              MultipartFile file,
                              Model model) throws Exception {
        pictureBoardService.write(pictureBoardEntity, file);
        model.addAttribute("message", "글 작성이 완료되었습니다.");
        model.addAttribute("searchUrl", "/");
        return "message";
    }

    @GetMapping("/pBoard/list")
    public String index(Model model, @PageableDefault(page = 0, size = 5, sort = "pId", direction = Sort.Direction.DESC) Pageable pageable,
                        String searchKeyword) {

        Page<PictureBoardEntity> list = null;

        if(searchKeyword == null) {
            list = pictureBoardService.pBoardList(pageable);
        } else {
            list = pictureBoardService.pBoardSearchList(searchKeyword, pageable);
        }

        int nowPage = list.getPageable().getPageNumber() + 1;
        int startPage = Math.max(nowPage - 4, 1);
        int endPage = Math.min(nowPage + 5, list.getTotalPages());

        model.addAttribute("pBoardList", list);
        model.addAttribute("nowPage", nowPage);
        model.addAttribute("startPage", startPage);
        model.addAttribute("endPage", endPage);
        return "indexPage";
    }


}

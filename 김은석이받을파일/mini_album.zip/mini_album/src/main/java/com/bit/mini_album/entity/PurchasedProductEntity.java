package com.bit.mini_album.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class PurchasedProductEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long ppId;

    @ManyToOne
    @JoinColumn(name = "uId")
    private UserEntity2 userEntity2;

    @ManyToOne
    @JoinColumn(name = "pId")
    private ProductEntity productEntity;

    private char applied;
    private int coordinateX;
    private int coordinateY;



}

package com.bit.mini_album.controller;

import com.bit.mini_album.entity.ProductEntity;
import com.bit.mini_album.entity.PurchasedProductEntity;
import com.bit.mini_album.entity.UserEntity2;
import com.bit.mini_album.service.PurchasedProductService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpSession;

@Controller
public class PurchasedProductController {
    private final PurchasedProductService purchasedProductService;


    public PurchasedProductController(PurchasedProductService purchasedProductService) {
        this.purchasedProductService = purchasedProductService;
    }

    @GetMapping("/purchase/{uId}")
    public String purchaseView(@PathVariable("uId") String uId, HttpSession session) {

        UserEntity2 loginUser = (UserEntity2) session.getAttribute("loginUser");

        if(loginUser == null) {
            return "redirect:/login";
        }
        return "miniroom";
    }

    @PostMapping("/purchase")
    public String purchase(PurchasedProductEntity purchasedProductEntity, HttpSession session,
                           ProductEntity productEntity) {

        UserEntity2 loginUser = (UserEntity2) session.getAttribute("loginUser");

        purchasedProductEntity.setUserEntity2(loginUser);

        if(loginUser.getBamtori() < productEntity.getProductPrice()) {
            return "charge";
        } else {
            purchasedProductEntity.setProductEntity(productEntity);
            purchasedProductService.purchase(purchasedProductEntity);
        } //값을 담아야하는데 비어잇음. 상품 엔티티. 매핑도 잘못되어있음


        return "redirect:/miniroom";



    }

//    @PostMapping("/preview")
//    public String preview() {
//
//    }
}

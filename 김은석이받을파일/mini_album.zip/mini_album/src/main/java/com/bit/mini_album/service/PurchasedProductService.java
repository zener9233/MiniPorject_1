package com.bit.mini_album.service;

import com.bit.mini_album.entity.PurchasedProductEntity;
import com.bit.mini_album.repository.PurchasedProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PurchasedProductService {

    private PurchasedProductRepository purchasedProductRepository;

    @Autowired
    public PurchasedProductService(PurchasedProductRepository purchasedProductRepository) {
        this.purchasedProductRepository = purchasedProductRepository;
    }

    public void purchase(PurchasedProductEntity purchasedProductEntity) {

        purchasedProductRepository.save(purchasedProductEntity);

    }
}

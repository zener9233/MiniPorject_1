package com.bit.mini_album.service;

import com.bit.mini_album.entity.PurchasedProductEntity;
import com.bit.mini_album.entity.UserEntity2;
import com.bit.mini_album.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    public void signup(UserEntity2 userEntity2) {

        userRepository.save(userEntity2);
    }

    public UserEntity2 login(UserEntity2 userEntity2) {
        Optional<UserEntity2> ue =userRepository.findByUserId(userEntity2.getUserId());
        if(ue.isPresent()) {
            UserEntity2 userEntity = ue.get();
            if(userEntity.getPassword().equals(userEntity2.getPassword())) {
                return userEntity;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
}

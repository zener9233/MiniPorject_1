package com.bit.mini_album.entity;

import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserEntity2 {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long uId;
    private String userId;
    private String password;
    private String userName;
    private String userNickName;
    private String sex;
    private String email;
    private int bamtori;

}

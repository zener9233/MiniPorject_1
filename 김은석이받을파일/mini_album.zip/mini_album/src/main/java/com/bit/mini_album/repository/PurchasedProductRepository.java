package com.bit.mini_album.repository;

import com.bit.mini_album.entity.PurchasedProductEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchasedProductRepository extends JpaRepository<PurchasedProductEntity, Long> {
}

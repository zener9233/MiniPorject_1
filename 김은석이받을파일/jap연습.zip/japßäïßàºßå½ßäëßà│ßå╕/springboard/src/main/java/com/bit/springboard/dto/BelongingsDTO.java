package com.bit.springboard.dto;


import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
//기본생성자
@AllArgsConstructor
//멤버변수를 모두 가진 생성자
@Builder
//stream을 이용해서 바로 객체를 하나 만들어줌.
@Data
public class BelongingsDTO {


    int productId;
    String productName;//
    int Uid;
    char Applied;//

    int coordinateX;//
    int coordinateY;//
    String productPath;//
     int productCate;




}

package com.bit.springboard.repository;

import com.bit.springboard.entity.Belongings;
import com.bit.springboard.entity.BelongingsId;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.beans.JavaBean;
import java.util.List;
import java.util.Optional;

@Transactional
public interface BelongingsRepository extends JpaRepository<Belongings, BelongingsId> {


    Optional<Belongings> findById(BelongingsId id);



    @Modifying
    @Query(value = "UPDATE belongings SET applied = 'O' WHERE product_Id = :productId", nativeQuery = true)
    void findByIdandChangeapply(@Param("productId") int productId);

    @Modifying
    @Query(value = "UPDATE belongings SET applied = 'X' WHERE product_Id = :productId", nativeQuery = true)


    void findByIdandChangedeapply(@Param("productId")  int productId);
    @Query(value = "Select * from belongings where applied = 'O'", nativeQuery = true)
    List<Belongings> findAllaplied();
}

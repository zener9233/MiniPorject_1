package com.bit.springboard.dto;

import com.bit.springboard.entity.User;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class UserDTO {



    private long Id;
    private String userId;
    private String userPw;
    private String userName;
    private String userEmail;
    private String userTel;
    private LocalDateTime userRegdate;


    public User DTOToEntity(){
        User user = User.builder().Id(this.Id).userPw(this.userPw).userName(this.userName).userTel(this.userTel).userRegdate(LocalDateTime.now()).userEmail(this.userEmail).userId(this.userId).build();


return user;


    }

}

package com.bit.springboard.repository;

import com.bit.springboard.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User,Long> {
    //select * from t_user

    //where user_id =:userId


    Optional<User> findByUserId(String userId);

}

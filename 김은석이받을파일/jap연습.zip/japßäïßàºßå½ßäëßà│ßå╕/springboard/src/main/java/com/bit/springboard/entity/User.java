package com.bit.springboard.entity;

import com.bit.springboard.dto.UserDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicUpdate;

import java.time.LocalDateTime;
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@DynamicUpdate
//@table : 테이블 이름등을 지정
/////////////////////////////이거 안써도됨?
@Table(name="T_USER")
//@SequenceGenerator(
//        name = "BoardSeqGenerator",
//        sequenceName = "T_USER_SEQ",
//        initialValue = 1,
//        allocationSize = 1
//)
@Data
public class User {
    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
//            generator = "BoardSeqGenerator"
    )
    private long Id;
    @Column(unique = true)
    private String userId;
    private String userPw;
    private String userName;
    private String userEmail;
    private String userTel;
    private LocalDateTime userRegdate =  LocalDateTime.now();
public UserDTO EntityToDTO(){
    UserDTO userDTO = UserDTO.builder().Id(this.Id).userId(this.userId).userName(this.userName).userEmail(this.userEmail).userTel(this.userTel).userRegdate(this.userRegdate).build();
    return userDTO;
}
}

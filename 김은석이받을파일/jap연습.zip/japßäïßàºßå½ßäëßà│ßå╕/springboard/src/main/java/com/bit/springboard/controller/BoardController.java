package com.bit.springboard.controller;

import com.bit.springboard.common.FileUtils;
import com.bit.springboard.dto.BoardDTO;
import com.bit.springboard.dto.BoardFileDTO;
import com.bit.springboard.dto.ResponseDTO;
import com.bit.springboard.entity.Board;
import com.bit.springboard.entity.BoardFile;
import com.bit.springboard.service.BoardService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//화면단으로 이동할때는 modelandview객체를 리턴해서 처리






@RestController
@RequestMapping("/board")
public class BoardController {

    @Value("${file.path}")
    String attachPath;
    private BoardService boardService;

    @Autowired
    public BoardController(BoardService boardService) {
        this.boardService = boardService;

    }

//    @GetMapping("/board-list")
//    public ResponseEntity<?> getBoardList() {
//        ResponseDTO<BoardDTO> responseDTO = new ResponseDTO<>();
//
//        try {
//            List<Board> boardList = boardService.getBoardList();
//            ////이게 대체 뭐하는작업임???
//            List<BoardDTO> boardDTOList = new ArrayList<>();
//            for (Board b : boardList) {
//                //게터세터 쉽게 사용하는거
//                BoardDTO returnBoardDTO = BoardDTO.builder().boardNo(b.getBoardNo()).boardTitle(b.getBoardTitle()).boardContent(b.getBoardContent()).boardWriter(b.getBoardWriter()).boardRegDate(b.getBoardRegdate().toString()).boardCnt(b.getBoardCnt()).build();
//                boardDTOList.add(returnBoardDTO);
//            }
//            responseDTO.setItems(boardDTOList);
//            responseDTO.setStatusCode(HttpStatus.OK.value());
//            return ResponseEntity.ok().body(responseDTO);
//        } catch (Exception e) {
//            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
//            responseDTO.setErrorMessage(e.getMessage());
//            return ResponseEntity.badRequest().body(responseDTO);
//        }
//    }

    @GetMapping("/board-list")
    public ModelAndView getBoardList() {

        ModelAndView mv = new ModelAndView();

//        ResponseDTO<BoardDTO> responseDTO = new ResponseDTO<>();


        List<Board> boardList = boardService.getBoardList();
        ////이게 대체 뭐하는작업임???
        List<BoardDTO> boardDTOList = new ArrayList<>();
        for (Board b : boardList) {
            //게터세터 쉽게 사용하는거
            BoardDTO returnBoardDTO = BoardDTO.builder().boardNo(b.getBoardNo()).boardTitle(b.getBoardTitle()).boardContent(b.getBoardContent()).boardWriter(b.getBoardWriter()).boardRegdate(b.getBoardRegdate().toString()).boardCnt(b.getBoardCnt()).build();
            boardDTOList.add(returnBoardDTO);
        }


        mv.addObject("boardList", boardDTOList);
        mv.setViewName("board/getBoardList.html");
        return mv;



    }












    @GetMapping("/insert-board-view")
    public ModelAndView insertboard() {

        ModelAndView mv = new ModelAndView();




        mv.setViewName("board/insertBoard.html");
        return mv;



    }












//
//
//
//
//    왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!왜 위는 boardDTO를 쓰고 아래는 안쓰는거지?!?!ㅍ





    @PostMapping("/board")
    public ResponseEntity<?> insertBoard(BoardDTO boardDTO, MultipartFile[] uploadFiles, HttpServletRequest request) {
        ResponseDTO<Map<String, String>> responseDTO = new ResponseDTO<>();

//        String attachPath = request.getSession().getServletContext().getRealPath("/") + "/upload/";


        File directory = new File(attachPath);
        if(!directory.exists()){
            directory.mkdir();
        }
        List<BoardFile> uploadFileList = new ArrayList<>();
        try {
            Board board = Board.builder().boardTitle(boardDTO.getBoardTitle()).boardContent(boardDTO.getBoardContent()).boardWriter(boardDTO.getBoardWriter()).boardRegdate(LocalDateTime.now()).build();
            for(int i=0;i<uploadFiles.length;i++){
                MultipartFile file = uploadFiles[i];
                if(file.getOriginalFilename()!=null&&!file.getOriginalFilename().equals("")){
                    BoardFile boardFile = new BoardFile();
                    boardFile = FileUtils.parseFileInfo(file,attachPath);
                    boardFile.setBoard(board);
                    uploadFileList.add(boardFile);


//
//                    BoardFile boardFile = BoardFile.builder().boardFileOrigin(uploadfiles[i].getOriginalFilename()).build();
//
//                    여기서는 이걸 왜 안하는거임?
//





                }
            }
            boardService.insertBoard(board, uploadFileList);
            Map<String, String> returnMap = new HashMap<>();
            returnMap.put("msg", "정상적으로 저장되었습니다.");
            responseDTO.setItem(returnMap);
            responseDTO.setStatusCode(HttpStatus.OK.value());
            return ResponseEntity.ok().body(responseDTO);
        } catch (Exception e) {
            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
            responseDTO.setErrorMessage(e.getMessage());
            return ResponseEntity.badRequest().body(responseDTO);
        }
    }


    @PutMapping("/board")
    public ResponseEntity<?> updateBoard(BoardDTO boardDTO) {
        ResponseDTO<Map<String, String>> responseDTO = new ResponseDTO<>();

        try {

            //BoardEntity에 지정한 boardRegdate의 기본값은 기본생성자 호출할 때먼 기본적으로 지정되는데 builder는 모든 매개변수를 갖는 생성자를 호출하기 때문에 boardRegdate의 값이 null로 들어간다.
            Board board = Board.builder().boardNo(boardDTO.getBoardNo()).boardTitle(boardDTO.getBoardTitle()).boardContent(boardDTO.getBoardContent()).boardWriter(boardDTO.getBoardWriter()).boardRegdate(LocalDateTime.parse(boardDTO.getBoardRegdate())).boardCnt(boardDTO.getBoardCnt()).build();
            boardService.updateBoard(board);
            Map<String, String> returnMap = new HashMap<>();
            returnMap.put("msg", "정상적으로수정됨");
            responseDTO.setItem(returnMap);
            responseDTO.setStatusCode(HttpStatus.OK.value());
            return ResponseEntity.ok().body(responseDTO);
        } catch (Exception e) {
            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
            responseDTO.setErrorMessage(e.getMessage());
            return ResponseEntity.badRequest().body(responseDTO);

        }

    }


    @DeleteMapping("/board")
    public ResponseEntity<?> deleteBoard(BoardDTO boardDTO) {
        ResponseDTO<Map<String, String>> responseDTO =
                new ResponseDTO<Map<String, String>>();

        try {
            boardService.deleteBoard(boardDTO.getBoardNo());

            Map<String, String> returnMap = new HashMap<String, String>();

            returnMap.put("msg", "정상적으로 삭제되었습니다.");

            responseDTO.setItem(returnMap);

            return ResponseEntity.ok().body(responseDTO);
        } catch (Exception e) {
            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
            responseDTO.setErrorMessage(e.getMessage());
            return ResponseEntity.badRequest().body(responseDTO);
        }
    }

    @GetMapping("/board/{boardNo}")
    public ModelAndView getBoard(@PathVariable int boardNo) {
        //이렇게하면 위에있는 보드넘버를 꺼내올 수 있다.
        ModelAndView mv = new ModelAndView();
            Board board = boardService.getBoard(boardNo);            ////이게 대체 뭐하는작업임???
                BoardDTO boardDTO = BoardDTO.builder().boardNo(board.getBoardNo()).boardContent(board.getBoardContent()).boardTitle(board.getBoardTitle()).boardRegdate(String.valueOf(board.getBoardRegdate())).boardCnt(board.getBoardCnt()).build();
                List<BoardFile>boardFileList = boardService.getBoardFileList(boardNo);
                List<BoardFileDTO> boardFileDTOList = new ArrayList<>();
                for(BoardFile boardFile : boardFileList){
                    BoardFileDTO boardFileDTO = boardFile.EntityToDTO();
                    boardFileDTOList.add(boardFileDTO);
                }
                mv.addObject("board",boardDTO);
                mv.setViewName("board/getBoard.html");
                mv.addObject("boardFileList",boardFileDTOList);
//언제는 왼쪽에 슬래시쓰고 언제는 안쓰는것인가!?!?!
            return mv;
    }


}

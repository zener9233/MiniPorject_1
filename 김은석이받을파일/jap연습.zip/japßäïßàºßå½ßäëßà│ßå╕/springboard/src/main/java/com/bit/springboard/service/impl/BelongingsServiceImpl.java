package com.bit.springboard.service.impl;

import com.bit.springboard.entity.Belongings;
import com.bit.springboard.entity.BelongingsId;
import com.bit.springboard.repository.BelongingsRepository;
import com.bit.springboard.service.BelongingsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class BelongingsServiceImpl  implements BelongingsService {

    private BelongingsRepository belongingsRepository;
    @Autowired
    public BelongingsServiceImpl(BelongingsRepository belongingsRepository){
        this.belongingsRepository = belongingsRepository;
    }

    @Override
    public List<Belongings> getBelongingsList() {
        return belongingsRepository.findAll();
    }

    @Override
    public Belongings getBelongings(BelongingsId id) {
        return belongingsRepository.findById(id).orElse(null);
    }
    @Transactional
    @Override
    public void productapply(int productId) {
        belongingsRepository.findByIdandChangeapply(productId);
    }

    @Override
    public void productdeapply(int productId) {
        belongingsRepository.findByIdandChangedeapply(productId);


    }

    @Override
    public List<Belongings> getappliedBelongingsList() {
        return belongingsRepository.findAllaplied();
    }
}

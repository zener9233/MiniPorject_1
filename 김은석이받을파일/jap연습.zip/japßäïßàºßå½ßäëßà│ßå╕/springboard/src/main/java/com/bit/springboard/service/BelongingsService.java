package com.bit.springboard.service;

import com.bit.springboard.entity.Belongings;
import com.bit.springboard.entity.BelongingsId;
import com.bit.springboard.entity.Board;

import java.util.List;

public interface BelongingsService {

    List<Belongings> getBelongingsList();

    Belongings getBelongings(BelongingsId id);

    void productapply(int productId);

    void productdeapply(int productId);

    List<Belongings> getappliedBelongingsList();
}

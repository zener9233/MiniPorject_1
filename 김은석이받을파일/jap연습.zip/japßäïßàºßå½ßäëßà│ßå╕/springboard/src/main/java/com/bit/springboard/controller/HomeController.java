package com.bit.springboard.controller;

import com.bit.springboard.dto.BelongingsDTO;
import com.bit.springboard.dto.ResponseDTO;
import com.bit.springboard.entity.Belongings;
import com.bit.springboard.entity.BelongingsId;
import com.bit.springboard.service.BelongingsService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/")
public class HomeController {

    @Value("${file.path}")
    String attachPath;


    BelongingsService belongingsService;
    public HomeController(BelongingsService belongingsService){
        this.belongingsService = belongingsService;
    }


    //창을 열자마자 내가 가지고있는 아이템리스트를 belongingList로, O로 적용된 아이템들을 appliedbelongingList로 가져와서 화면에 뿌린다.
    //미니룸 꾸미기 보는 첫 화면
    @GetMapping("/haha")
    public ModelAndView haha(){
        ModelAndView mv = new ModelAndView();
        List<Belongings> belongingsList = belongingsService.getBelongingsList().stream().filter(b->b.getProductCate()==2).collect(Collectors.toList());
        mv.addObject("belongingsList",belongingsList);
List<Belongings>appliedbelongingsList = belongingsService.getappliedBelongingsList().stream().filter(b->b.getProductCate()==2||b.getProductCate()==3).collect(Collectors.toList());
List<Belongings>wallpaperlist = belongingsService.getappliedBelongingsList().stream().filter(b->b.getProductCate()==1).toList();

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String appliedbelongingsListJson = objectMapper.writeValueAsString(appliedbelongingsList);

            mv.addObject("appliedbelongingsList", appliedbelongingsListJson);
            mv.setViewName("haha.html");
            mv.addObject("wallpaperlist",wallpaperlist);
            System.out.println(appliedbelongingsList);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return mv;

    }


    @GetMapping("/myroombgm")
    public ModelAndView myroombgm(){
        ModelAndView mv = new ModelAndView();
        mv.setViewName("myroombgm.html");
        return mv;
    }


    @GetMapping("/deco-wallpaper")
    public ModelAndView decowallpaperview(){
        ModelAndView mv = new ModelAndView();
        List<Belongings> belongingsList = belongingsService.getBelongingsList().stream().filter(b->b.getProductCate()==1).collect(Collectors.toList());
        mv.addObject("belongingsList",belongingsList);
        List<Belongings>appliedbelongingsList = belongingsService.getappliedBelongingsList().stream().filter(b->b.getProductCate()==2||b.getProductCate()==3).collect(Collectors.toList());
        List<Belongings>wallpaperlist = belongingsService.getappliedBelongingsList().stream().filter(b->b.getProductCate()==1).toList();

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String appliedbelongingsListJson = objectMapper.writeValueAsString(appliedbelongingsList);

            mv.addObject("appliedbelongingsList", appliedbelongingsListJson);
            mv.setViewName("decowallpaper.html");
            mv.addObject("wallpaperlist",wallpaperlist);
            System.out.println(appliedbelongingsList);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return mv;

    }





    @GetMapping("/minimi-decoration")
    public ModelAndView minimiview(){
        ModelAndView mv = new ModelAndView();
        List<Belongings> belongingsList = belongingsService.getBelongingsList().stream().filter(b->b.getProductCate()==3).collect(Collectors.toList());
        mv.addObject("belongingsList",belongingsList);
        List<Belongings>appliedbelongingsList = belongingsService.getappliedBelongingsList().stream().filter(b->b.getProductCate()==3).collect(Collectors.toList());



            mv.addObject("appliedbelongingsList", appliedbelongingsList);
            mv.setViewName("minimidecoration.html");

        return mv;

    }




//적용버튼을 누를때
    @PostMapping("product-apply")
    public ResponseEntity<?> productapply(@RequestParam int uid, @RequestParam int productId){
//        public ResponseEntity<?> productapply(@AuthenticationPrincipal CustomUserDetails user, @RequestParam int productId){



        ResponseDTO<BelongingsDTO> responseDTO = new ResponseDTO<>();
        Map<String,String> returnmap = new HashMap<>();

        try {
            BelongingsId id = new BelongingsId(productId, uid);
            Belongings belongings = belongingsService.getBelongings(id);

            BelongingsDTO belongingsDTO = BelongingsDTO.builder().Applied(belongings.getApplied()).coordinateX(belongings.getCoordinateX()).productName(belongings.getProductName()).productPath(belongings.getProductPath()).coordinateY(belongings.getCoordinateY()).productId(belongings.getId().getProductId()).productCate(belongings.getProductCate()).Uid(belongings.getId().getUid()).build();
            System.out.println(belongingsDTO);
            responseDTO.setItem(belongingsDTO);
            responseDTO.setStatusCode(HttpStatus.OK.value());

            return ResponseEntity.ok().body(responseDTO);

        } catch (Exception e) {
            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
            responseDTO.setErrorMessage(e.getMessage());
            return ResponseEntity.badRequest().body(responseDTO);
        }


    }

//적용하기 누르면 db에 o로 저장되게하는거
    @PostMapping("productdb-apply")
    public ResponseEntity<?> productdbapply(@RequestParam int productId){
        ResponseDTO<Map<String,String>> responseDTO = new ResponseDTO<>();
        Map<String,String> returnmap = new HashMap<>();
        try {

            belongingsService.productapply(productId);
            returnmap.put("msg","applied");
            responseDTO.setItem(returnmap);
            responseDTO.setStatusCode(HttpStatus.OK.value());
            return ResponseEntity.ok().body(responseDTO);
        } catch (Exception e) {
            responseDTO.setStatusCode(HttpStatus.OK.value());
            responseDTO.setErrorMessage(e.getMessage());
            return ResponseEntity.badRequest().body(responseDTO);
        }
    }

//적용하기 누르면 db에 X로 저장되게하는거

    @PostMapping("productdb-deapply")
    public ResponseEntity<?> productdbdeapply(@RequestParam int productId){
        ResponseDTO<Map<String,String>> responseDTO = new ResponseDTO<>();
        Map<String,String> returnmap = new HashMap<>();
        try {

            belongingsService.productdeapply(productId);
            returnmap.put("msg","deapplied");
            responseDTO.setItem(returnmap);
            responseDTO.setStatusCode(HttpStatus.OK.value());
            return ResponseEntity.ok().body(responseDTO);
        } catch (Exception e) {
            responseDTO.setStatusCode(HttpStatus.OK.value());
            responseDTO.setErrorMessage(e.getMessage());
            return ResponseEntity.badRequest().body(responseDTO);
        }
    }

}

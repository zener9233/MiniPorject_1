//import com.bit.springboard.dto.BoardDTO;
//import com.bit.springboard.dto.ResponseDTO;
//import com.bit.springboard.service.BoardService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@RestController
//@RequestMapping("/api")
//public class ApiController{
//
//    BoardService boardService;
//
//    @Autowired
//    ApiController(BoardService boardService){
//        this.boardService = boardService;
//    }
//
//
//    @GetMapping("/board")
//    public ResponseEntity<?> getBoard(int BoardNo){
//        ResponseDTO<BoardDTO> responseDTO = new ResponseDTO<>();
//
//
//        try {
//            responseDTO.setItem(boardService.getBoard(BoardNo));
//            responseDTO.setStatusCode(HttpStatus.OK.value());
//
//            return  ResponseEntity.ok().body(responseDTO);
//        } catch (Exception e) {
//            responseDTO.setErrorMessage(e.getMessage());
//            responseDTO.setStatusCode(HttpStatus.OK.value());
//            return  ResponseEntity.badRequest().body(responseDTO);
//        }
//
//
//    }
//
//    @PostMapping("/board")
//    public ResponseEntity<?> insertBoard(BoardDTO boardDTO){
//        ResponseDTO<Map<String,Object>> responseDTO = new ResponseDTO<>();
//
//
//        try {
//            boardService.insertBoard(boardDTO);
//            Map<String,Object> returnmap = new HashMap<>();
//
//            returnmap.put("msg","삽입성공");
//            responseDTO.setStatusCode(HttpStatus.OK.value());
//            responseDTO.setItem(returnmap);
//            return ResponseEntity.ok().body(responseDTO);
//        } catch (Exception e) {
//            responseDTO.setErrorMessage(e.getMessage());
//            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
//            return  ResponseEntity.badRequest().body(responseDTO);
//        }
//    }
//
//    @PutMapping("/board")
//    public ResponseEntity<?> updateBoard(BoardDTO boardDTO){
//
//        ResponseDTO<Map<String,Object>> responseDTO = new ResponseDTO<>();
//
//
//        try {
//            boardService.updateBoard(boardDTO);
//            responseDTO.setStatusCode(HttpStatus.OK.value());
//            Map<String,Object> returnmap = new HashMap<>();
//            returnmap.put("msg","update success");
//            responseDTO.setItem(returnmap);
//            return ResponseEntity.ok().body(responseDTO);
//        } catch (Exception e) {
//            responseDTO.setErrorMessage(e.getMessage());
//            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
//            return ResponseEntity.badRequest().body(responseDTO);
//
//        }
//
//
//    }
//
//
//    @DeleteMapping("/board")
//    public ResponseEntity<?> deleteboard(int Boardno){
//ResponseDTO<Map<String,Object>> responseDTO = new ResponseDTO<>() ;
//
//        try {
//            boardService.deleteBoard(Boardno);
//            responseDTO.setStatusCode(HttpStatus.OK.value());
//            Map<String,Object> returnmap = new HashMap<>();
//            returnmap.put("msg","delete succded");
//            responseDTO.setItem(returnmap);
//            return ResponseEntity.ok().body(responseDTO);
//        } catch (Exception e) {
//            responseDTO.setErrorMessage(e.getMessage());
//            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
//            return ResponseEntity.badRequest().body(responseDTO);
//
//
//        }
//
//
//    }
//
//
//
//    @GetMapping("/board-list")
//    public ResponseEntity<?> getBoardlist(){
//        ResponseDTO<BoardDTO> responseDTO = new ResponseDTO<>();
//
//
//        try {
//            responseDTO.setItems(boardService.getBoardList());
//            responseDTO.setStatusCode(HttpStatus.OK.value());
//            return ResponseEntity.ok().body(responseDTO);
//        } catch (Exception e) {
//            responseDTO.setErrorMessage(e.getMessage());
//            responseDTO.setStatusCode(HttpStatus.BAD_REQUEST.value());
//            return ResponseEntity.badRequest().body(responseDTO);
//        }
//
//
//    }
//
//
//}
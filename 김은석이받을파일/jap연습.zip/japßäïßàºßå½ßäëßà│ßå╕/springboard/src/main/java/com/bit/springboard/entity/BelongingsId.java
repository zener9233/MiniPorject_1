package com.bit.springboard.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Embeddable
public class BelongingsId implements Serializable {
    @Column(name="PRODUCT_ID")
    private int productId;
    @Column(name="UID")
    private int uid;

    // equals() and hashCode() methods
}
package com.bit.springboard.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name = "BELONGINGS")
@SequenceGenerator(
        name = "BoardSeqGenerator",
        sequenceName = "T_BOARD_SEQ",
        allocationSize = 1
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@DynamicUpdate
public class Belongings {
    @EmbeddedId
    private BelongingsId Id;

    @Column(name = "PRODUCT_NAME", length = 500)
    private String productName;



    @Column(name = "APPLIED")
    private char applied;

    @Column(name = "COORDINATE_X")
    private int coordinateX;

    @Column(name = "COORDINATE_Y")
    private int coordinateY;

    @Column(name = "PRODUCT_PATH", length = 2000)
    private String productPath;

    @Column(name="PRODUCT_CATE")
    private int productCate;

}
